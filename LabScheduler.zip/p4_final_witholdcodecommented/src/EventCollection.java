
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Author: Sarah Perlotto
 * Date: 4/14/2014
 * Course: CSC 240-470
 * Title: Lab Request Scheduler - Event Collection
 * Description: Collects lab request input data from user
 */

public class EventCollection
{
    //Class variables
    public ArrayList<Event> events = new ArrayList<Event>();
    private static FrmLabRequest parent = null;
    private Object[][] eventData = null;
    
    //Constructor
    public EventCollection(FrmLabRequest frame)
    {
        this.parent = frame;
    }
    
    //Add event to event/object to event collection/array list
    public void addEvent(Event newEvent)
    {
        events.add(newEvent);
        //Use Java sort to sort into EventCollection
        Collections.sort(events, new Comparator<Event>()
        {
            @Override
            public int compare(Event evt1, Event evt2)
            {
                return evt1.getStartTime().compareTo(evt2.getStartTime());
            }
        });
    }
    
    //Clear events
    public void clearEvents() {events.clear();}
    
    //Get number of events in scheduled event collection
    public int numEvents() {return events.size();}
    
    //Look up event by index in 2d array
    public Event getEventAtIndex(int x) 
    {
        if(x >= 0 && x < numEvents())
        {
            return(events.get(x));
        }
        else 
        {
            return null; //Is this really the best choice?
        }
    }
    
    public Object[][] to2DArray()
    {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm a");
        
        if(numEvents()>0) 
        {
            eventData = new Object[numEvents()][4];
        }
        
        //Send event data to 2d array
        for (int i = 0; i < numEvents(); i++)
        {
            Event sched = events.get(i);
            eventData[i][0] = sched.getEventTitle();

            //Parse date Calendar object into formatted string to display
            Date eventDate = sched.getEventDate().getTime();
            String eventDateString = dateFormat.format(eventDate);
            eventData[i][1] = eventDateString;

            //Parse start time Calendar object into formatted string to display
            Date startTime = sched.getStartTime().getTime();
            String startTimeString = timeFormat.format(startTime);
            eventData[i][2] = startTimeString;

            //Parse end time Calendar object into formatted string to display
            Date endTime = sched.getEndTime().getTime();
            String endTimeString = timeFormat.format(endTime);
            eventData[i][3] = endTimeString;
        }
        return (eventData);
    } 
}
