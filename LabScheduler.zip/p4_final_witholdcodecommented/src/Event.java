
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Author: Sarah Perlotto
 * Date: 5/2014
 * Course: CSC 240-470
 * Title: Lab Request Scheduler - Event
 * Description: Collects lab request input data from user
 */

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;

public class Event implements java.io.Serializable
{
    //Class Variables
    private String eventTitle;
    private String eventDate;
    private String eventStartTime;
    private String eventEndTime;
    private Calendar calDate;
    private Calendar calStartTime;
    private Calendar calEndTime;
    private int conflictIndex = -1;
    private int year = 0;
    private int month = 0;
    private int day = 0;

    //Constructor
    public Event(String theTitle, String theDate, String theStartTime, String theEndTime) 
    {     
        eventTitle = theTitle;
        eventDate = theDate;
        eventStartTime = theStartTime;
        eventEndTime = theEndTime;
        calDate = parseDate(theDate); //Do first, so year/month/date in start time
        calStartTime = parseTime(theStartTime);
        calEndTime = parseTime(theEndTime);
        
        //Set conflict index to default negative value
        conflictIndex = -1;
    }
    
    //Get methods
    public String getEventTitle() {return(eventTitle);}
    public String getEventDateStr() {return (eventDate);}
    public String getStartTimeStr() {return (eventStartTime);}
    public String getEndTimeStr() {return (eventEndTime);}
    public Calendar getEventDate() {return(calDate);}
    public Calendar getStartTime() {return(calStartTime);}
    public Calendar getEndTime() {return(calEndTime);}
    public int getConflictIndex() {return(conflictIndex);}
    
    //Parse string into date format Calendar object
    private Calendar parseDate(String date) 
    {
        Calendar parsedDate = Calendar.getInstance();
        try
        {
            SimpleDateFormat dateParser = new SimpleDateFormat("M/d/y");
            Date parserDate = dateParser.parse(date);
            parsedDate.setTime(parserDate);
            parsedDate.set(Calendar.HOUR, 0);
            parsedDate.set(Calendar.MINUTE, 0);
            parsedDate.set(Calendar.SECOND, 0);
            parsedDate.set(Calendar.MILLISECOND, 0);
            month = parsedDate.get(Calendar.MONTH);
            day = parsedDate.get(Calendar.DAY_OF_MONTH);
            year = parsedDate.get(Calendar.YEAR);
        }
        catch (ParseException ex)
        {
            JOptionPane.showMessageDialog(null, "Invalid date", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return parsedDate;
    }
    
    //Parse string into time format Calendar object
    private Calendar parseTime(String time) 
    {
        Calendar parsedTime = Calendar.getInstance();
        try
        {
            SimpleDateFormat timeParser = new SimpleDateFormat("h:mm a");
            parsedTime.setTime(timeParser.parse(time));
            parsedTime.set(Calendar.SECOND, 0);
            parsedTime.set(Calendar.MILLISECOND, 0);
            parsedTime.set(Calendar.MONTH,month);
            parsedTime.set(Calendar.DAY_OF_MONTH,day);
            parsedTime.set(Calendar.YEAR,year);
        }
        catch (ParseException ex)
        {
            JOptionPane.showMessageDialog(null, "Invalid time", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return parsedTime;
    }
   
    //Check the requested event against the scheduled events
    public boolean isAvailable(EventCollection evtCollect) 
    {
        try
        {
            int numberEvents = evtCollect.numEvents();
            
            //Loop through scheduledEvents EventCollection...
            for (int i = 0; i < numberEvents; i++)
            {
                //If events have matching dates...
                Calendar reqEvtDate = getEventDate();
                Event schedEvt = evtCollect.getEventAtIndex(i);
                Calendar schedEvtDate = schedEvt.getEventDate();

                if (reqEvtDate.compareTo(schedEvtDate)==0)
                {
                    //If requested start time IS NOT at/after scheduled end time
                    //or requested end time IS NOT at/before scheduled start time
                    Calendar reqEvtStart = getStartTime();
                    Calendar reqEvtEnd = getEndTime();
                    Calendar schedEvtStart = schedEvt.getStartTime();
                    Calendar schedEvtEnd = schedEvt.getEndTime();

                    //x.compareTo(y) returns 0 if x and y are equal; - value if x is before y; + value if x is after y
                    int rs2se = reqEvtStart.compareTo(schedEvtEnd);
                    int re2ss = reqEvtEnd.compareTo(schedEvtStart);
                    boolean before = (re2ss <= 0); //True if adj or all before
                    boolean after = (rs2se >= 0); //True if adj or all after     

                    if (!(before || after))
                    {
                        //Capture index of conflicting event
                        conflictIndex = i;
                        //Reject
                        return (false);
                    }
                }
            }
//            //Breakdown requested event date/time components
//            Calendar reqEvtDate = getEventDate();
//            Calendar reqEvtStart = getStartTime();
//            Calendar reqEvtEnd = getEndTime();
//            
//            //Loop through scheduledEvents EventCollection...
//            for(int i=0; i<evtCollect.numEvents(); i++) 
//            {
//                //Breakdown scheduled event at i date/time components
//                Event schedEvt = evtCollect.getEventAtIndex(i);
//                Calendar schedEvtDate = schedEvt.getEventDate();
//                Calendar schedEvtStart = schedEvt.getStartTime();
//                Calendar schedEvtEnd = schedEvt.getEndTime();
//                
//                //If events have matching dates...
//                if(reqEvtDate.compareTo(schedEvtDate)==0)
//                {
//                    //NOTE: x.compareTo(y) returns 0 if x and y are equal; - value if x is before y; + value if x is after y
//                    //If requested event ends after scheduled event starts AND before scheduled event ends
//                    //OR//
//                    //If requested event starts before scheduled event ends AND after scheduled event starts
//                    if(((reqEvtEnd.compareTo(schedEvtStart) > 0) && (reqEvtEnd.compareTo(schedEvtEnd) < 0))
//                            || ((reqEvtStart.compareTo(schedEvtEnd) < 0) && (reqEvtStart.compareTo(schedEvtStart) > 0)))
//                    {
//                        //Capture index of conflicting event
//                        conflictIndex = i;
//                        //Reject
//                        return (false);
//                    }
//                }
//            }
        }
        catch (Exception ex1)
        {
           JOptionPane.showMessageDialog(null, ex1, "Error checking event availability", JOptionPane.ERROR_MESSAGE);         
        }
        
        //"Conflict index" of neg value when no conflict since zero is an index!
        conflictIndex = -1;
        //Accept
        return (true);
    }
}
