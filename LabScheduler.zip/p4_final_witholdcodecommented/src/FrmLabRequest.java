/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Author: Sarah Perlotto
 * Date: 2/23/2014
 * Course: CSC 240-470
 * Title: Lab Reqest Scheduler
 * Description: Collects lab request input data from user
 * Displays appt recurrence info when submitted
 */

import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FrmLabRequest extends javax.swing.JFrame implements java.io.Serializable
{
    //Class instance variables
    private String inputName = "";
    private String inputEmail = "";
    private String inputEventTitle = "";
    private String inputEventDate = "";
    private String inputStartTime = "";
    private String inputEndTime = "";
    private String inputArea = "";
    private String inputNumParticipants = "";
    private int numParticipants = 0;
    private boolean inputStartPM = false; //True=PM, False=AM
    private boolean inputEndPM = false; //True=PM, False=AM
    private boolean inputPrinterReq = false;
    private boolean inputSpecReq = false;
    private String apptRecurrenceInfo = "";
    private boolean recurrence = false;
    private Event newEvent = null;
    private EventCollection requestedEvents = null;
    private EventCollection scheduledEvents = null;
    private String scheduledFile = "events.csv";
    private int numAvailable=0;
    ArrayList<Event> availableEvents = new ArrayList<>();
    
    //Serialization
    private String scheduledListFile = "scheduled.ser";
    private FileOutputStream fos = null;
    private ObjectOutputStream oos = null;
    private FileInputStream fis = null;
    private ObjectInputStream ois = null;

    //CONSTRUCTOR 
    public FrmLabRequest() throws Exception
    {
        initComponents();
        clearFields();
        
        //Initialize EventCollections
        requestedEvents = new EventCollection(this);
        scheduledEvents = new EventCollection(this);
        
        //INSTRUCTIONS:
        //For first run, uncomment bootstrap() and comment readEventList()
        //Run, select submit and OK, then close
        //Comment bootstrap() and uncomment readEventList() for production use
        //This will load scheduledEvents with data in events.csv
//        bootstrap(); //Temp method used to read from events.csv and load scheduledEvents
        readEventList(); //Production method used to read from scheduled.ser and load scheduledEvents

//        //Read events from .csv file, add to scheduledEvents EventCollection
//        try 
//        {
//            BufferedReader iFile = new BufferedReader(new FileReader(scheduledFile));
//            String line = iFile.readLine(); //Read column titles
//            while ((line = iFile.readLine()) != null) 
//            {
//                String[] tokens = line.split(",");
//                if(tokens.length==4) 
//                {
//                    String evtTitle = tokens[0];
//                    String evtDate = tokens[1];
//                    String evtStartTime = tokens[2];
//                    String evtEndTime = tokens[3];
//                    Event evt = new Event(evtTitle, evtDate, evtStartTime, evtEndTime);
//                    scheduledEvents.addEvent(evt);
//                }
//            }
//        } 
//        catch (FileNotFoundException ex1) 
//        {
//            JOptionPane.showMessageDialog(null, ex1, "Error - file not found", JOptionPane.ERROR_MESSAGE);
//        }
//        catch (IOException ex2) 
//        {
//            JOptionPane.showMessageDialog(null, ex2, "Error - I/O file reader error", JOptionPane.ERROR_MESSAGE);
//        }
//        catch (Exception ex3) //Generic exception catch
//        {
//            JOptionPane.showMessageDialog(null, ex3, "Error", JOptionPane.ERROR_MESSAGE);
//        }
        
        //Action Listeners
        this.btnApptRecur.addActionListener(new MyApptRecurActionListener(this));
        this.btnReview.addActionListener(new MyReviewApptActionListener(this));
        this.btnClear.addActionListener(new MyClearActionListener(this));
        this.btnSubmit.addActionListener(new MySubmitActionListener(this));
        this.btnClose.addActionListener(new MyCloseActionListener(this));
        this.btnSpecReqYes.addActionListener(new MySpecialRequestYesActionListener(this));
        this.btnSpecReqNo.addActionListener(new MySpecialRequestNoActionListener(this));

        //Group special request buttons so only one may be selected 
        ButtonGroup specReq = new ButtonGroup();
        specReq.add(btnSpecReqYes);
        specReq.add(btnSpecReqNo);
    }
    
    //Methods for serialization
    private void bootstrap()
    {
        //Read events from .csv file, add to scheduledEvents EventCollection
        try
        {
            BufferedReader iFile = new BufferedReader(new FileReader(scheduledFile));
            String line = iFile.readLine(); //Read column titles
            while ((line = iFile.readLine()) != null)
            {
                String[] tokens = line.split(",");
                if (tokens.length == 4)
                {
                    String evtTitle = tokens[0];
                    String evtDate = tokens[1];
                    String evtStartTime = tokens[2];
                    String evtEndTime = tokens[3];
                    Event evt = new Event(evtTitle, evtDate, evtStartTime, evtEndTime);
                    scheduledEvents.addEvent(evt);
                }
            }
        }
        catch (FileNotFoundException ex1)
        {
            JOptionPane.showMessageDialog(null, ex1, "Error - file not found", JOptionPane.ERROR_MESSAGE);
        }
        catch (IOException ex2)
        {
            JOptionPane.showMessageDialog(null, ex2, "Error - I/O file reader error", JOptionPane.ERROR_MESSAGE);
        }
        catch (Exception ex3)
        {
            JOptionPane.showMessageDialog(null, ex3, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void readEventList()
    {
        //Read the event serialization file if it exists
        File ser = new File(scheduledListFile);
        if (ser.exists())
        {
            try
            {
                fis = new FileInputStream(scheduledListFile);
                ois = new ObjectInputStream(fis);
                scheduledEvents.events = (ArrayList<Event>) ois.readObject();
            }
            catch (Exception ex1)
            {
                JOptionPane.showMessageDialog(null, ex1, "Error accessing file", JOptionPane.ERROR_MESSAGE);
            }
            finally
            {
                if (ois != null)
                {
                    try
                    {
                        ois.close();
                    }
                    catch (IOException ex2)
                    {
                        JOptionPane.showMessageDialog(null, ex2, "Error accessing file", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }
        return;
    }

    private void writeEventList(ArrayList<Event> eventList)
    {
        try
        {
            fos = new FileOutputStream(scheduledListFile, false); //false==overwrite
            oos = new ObjectOutputStream(fos);
            oos.writeObject(eventList);
        }
        catch(Exception ex3)
        {
            JOptionPane.showMessageDialog(null, ex3, "Error accessing file", JOptionPane.ERROR_MESSAGE);
        }
        finally
        {
            if (oos!=null)
            {
                try
                {
                    oos.close();
                }
                catch(IOException ex4)
                {
                    JOptionPane.showMessageDialog(null, ex4, "Error accessing file", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        return;
    }
    
    //Get methods
    public String getInputName() {return (inputName);}
    public String getEventTitle() {return (txtEventTitle.getText());}
    public String getDate() {return (txtDate.getText());}
    public String getStartTime() {return (txtStartTime.getText());}
    public boolean getStartPM() {return (btnStartPM.isSelected());}
    public String getEndTime() {return (txtEndTime.getText());}
    public boolean getEndPM() {return (btnEndPM.isSelected());}
    public EventCollection getRequestedEvents() {return (requestedEvents);}
    public EventCollection getScheduledEvents() 
    {
        readEventList();
        return (scheduledEvents);
    }
    public Event getRequestedEvent() 
    {
        Event evt = null;
        evt = requestedEvents.events.get(0); //TO DO - protect against null
        return evt;
    }
    
    //Set methods
    public void setNumAvailable(int numAvail) 
    {
        numAvailable = numAvail;
    }
    public void setAvailableEvents(ArrayList<Event> availEvts) 
    {
        availableEvents.clear();
        availableEvents.addAll(availEvts);
    }

    
    /*
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        lblName = new javax.swing.JLabel();
        lblEmail = new javax.swing.JLabel();
        lblTitle = new javax.swing.JLabel();
        lblNoParticipants = new javax.swing.JLabel();
        lblDate = new javax.swing.JLabel();
        lblStartTime = new javax.swing.JLabel();
        lblEndTime = new javax.swing.JLabel();
        lblSoftReqSpecInstruct = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtEventTitle = new javax.swing.JTextField();
        txtNumParticipants = new javax.swing.JTextField();
        txtDate = new javax.swing.JTextField();
        txtStartTime = new javax.swing.JTextField();
        txtEndTime = new javax.swing.JTextField();
        btnStartPM = new javax.swing.JToggleButton();
        btnEndPM = new javax.swing.JToggleButton();
        btnPrinterReq = new javax.swing.JCheckBox();
        txtAreaPane = new javax.swing.JScrollPane();
        txtArea = new javax.swing.JTextArea();
        btnSubmit = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnClose = new javax.swing.JButton();
        btnSpecReqYes = new javax.swing.JRadioButton();
        btnSpecReqNo = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        btnApptRecur = new javax.swing.JButton();
        lblApptRecur = new javax.swing.JLabel();
        btnReview = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblName.setText("Requestor Name:");

        lblEmail.setText("Requestor Email:");

        lblTitle.setText("Event Title:");

        lblNoParticipants.setText("Number of Participants:");

        lblDate.setText("Event Date (MM/DD/YYYY):");

        lblStartTime.setText("Start Time (HH:MM):");

        lblEndTime.setText("End Time (HH:MM):");

        lblSoftReqSpecInstruct.setText("Software Requests/Special Instructions:");

        txtName.setPreferredSize(new java.awt.Dimension(150, 30));

        txtEmail.setPreferredSize(new java.awt.Dimension(150, 30));

        txtEventTitle.setPreferredSize(new java.awt.Dimension(150, 30));

        txtNumParticipants.setPreferredSize(new java.awt.Dimension(100, 30));

        txtDate.setPreferredSize(new java.awt.Dimension(100, 30));

        txtStartTime.setPreferredSize(new java.awt.Dimension(100, 30));

        txtEndTime.setPreferredSize(new java.awt.Dimension(100, 30));

        btnStartPM.setText("PM");
        btnStartPM.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnStartPMActionPerformed(evt);
            }
        });

        btnEndPM.setText("PM");
        btnEndPM.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEndPMActionPerformed(evt);
            }
        });

        btnPrinterReq.setText("Printer Requested");

        txtArea.setColumns(20);
        txtArea.setRows(5);
        txtAreaPane.setViewportView(txtArea);

        btnSubmit.setText("Submit");

        btnClear.setText("Clear All Fields");
        btnClear.setPreferredSize(new java.awt.Dimension(105, 23));

        btnClose.setText("Close");
        btnClose.setPreferredSize(new java.awt.Dimension(105, 23));

        btnSpecReqYes.setText("Yes");

        btnSpecReqNo.setText("No");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Lab Scheduling Request Form");

        btnApptRecur.setText("Appointment Recurrence");

        lblApptRecur.setText("There is no appointment recurrence set");

        btnReview.setText("Review Event Listings and Check Availability");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblApptRecur)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnApptRecur, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(lblStartTime)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtStartTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnStartPM)))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(0, 23, Short.MAX_VALUE)
                                        .addComponent(lblEndTime)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtEndTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnEndPM))
                                    .addComponent(btnReview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnSubmit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtAreaPane, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnPrinterReq)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblSoftReqSpecInstruct)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnSpecReqYes)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnSpecReqNo))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblEmail)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblTitle)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtEventTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblNoParticipants)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtNumParticipants, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblDate)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblName)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel1)
                                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblName)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblEmail)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitle)
                    .addComponent(txtEventTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNoParticipants)
                    .addComponent(txtNumParticipants, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDate)
                    .addComponent(txtDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblStartTime)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtStartTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnStartPM))
                    .addComponent(lblEndTime)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtEndTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnEndPM)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnApptRecur)
                    .addComponent(btnReview))
                .addGap(9, 9, 9)
                .addComponent(lblApptRecur)
                .addGap(13, 13, 13)
                .addComponent(btnPrinterReq)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSoftReqSpecInstruct)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnSpecReqYes)
                        .addComponent(btnSpecReqNo)))
                .addGap(18, 18, 18)
                .addComponent(txtAreaPane, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSubmit)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnStartPMActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnStartPMActionPerformed
    {//GEN-HEADEREND:event_btnStartPMActionPerformed
        if(this.btnStartPM.isSelected())
            this.btnStartPM.setText("PM");
        else 
            this.btnStartPM.setText("AM");
    }//GEN-LAST:event_btnStartPMActionPerformed

    private void btnEndPMActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnEndPMActionPerformed
    {//GEN-HEADEREND:event_btnEndPMActionPerformed
        if(this.btnEndPM.isSelected())
            this.btnEndPM.setText("PM");
        else 
            this.btnEndPM.setText("AM");
    }//GEN-LAST:event_btnEndPMActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmLabRequest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmLabRequest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmLabRequest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmLabRequest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                try 
                {
                    new FrmLabRequest().setVisible(true);
                } 
                catch (Exception ex) 
                {
                    Logger.getLogger(FrmLabRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnApptRecur;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnClose;
    private javax.swing.JToggleButton btnEndPM;
    private javax.swing.JCheckBox btnPrinterReq;
    private javax.swing.JButton btnReview;
    private javax.swing.JRadioButton btnSpecReqNo;
    private javax.swing.JRadioButton btnSpecReqYes;
    private javax.swing.JToggleButton btnStartPM;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblApptRecur;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblEndTime;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblNoParticipants;
    private javax.swing.JLabel lblSoftReqSpecInstruct;
    private javax.swing.JLabel lblStartTime;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTextArea txtArea;
    private javax.swing.JScrollPane txtAreaPane;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEndTime;
    private javax.swing.JTextField txtEventTitle;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtNumParticipants;
    private javax.swing.JTextField txtStartTime;
    // End of variables declaration//GEN-END:variables

    //Set txtArea and txtAreaPane to visible for Special Requests (Yes) selection    
    class MySpecialRequestYesActionListener implements ActionListener 
    {
        private FrmLabRequest mainApp = null;

        //Constructor
        public MySpecialRequestYesActionListener(FrmLabRequest theApp)
        {
            mainApp = theApp;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (btnSpecReqYes.isSelected()) 
            {
                txtAreaPane.setVisible(true);
                txtArea.setVisible(true);
                mainApp.setVisible(true); //Refresh GUI
            }
        }
    }

    //Set txtArea and txtAreaPane to not be visible for Special Requests (No) selection
    class MySpecialRequestNoActionListener implements ActionListener 
    {
        private FrmLabRequest mainApp = null;

        //Constructor
        public MySpecialRequestNoActionListener(FrmLabRequest theApp)
        {
            mainApp = theApp;
        }

        @Override
        public void actionPerformed(ActionEvent e) 
        {
            if (btnSpecReqNo.isSelected()) 
            {
                txtAreaPane.setVisible(false);
                txtArea.setVisible(false);
                mainApp.setVisible(true); //Refresh GUI
            }
        }
    }

    //Open appointment recurrence frame and hide lab request frame when selected
    class MyApptRecurActionListener implements ActionListener 
    {
        FrmLabRequest parent = null;

        //Constructor
        public MyApptRecurActionListener(FrmLabRequest theApp)
        {
            this.parent = theApp;
        }

        @Override
        public void actionPerformed(ActionEvent e) 
        {
            FrmApptRecurrence myFrame = new FrmApptRecurrence(parent);
            myFrame.setVisible(true);
            parent.setVisible(false);
        }
    }

    //Open event listings frame and hide lab request frame when selected
    class MyReviewApptActionListener implements ActionListener 
    {
        FrmLabRequest parent = null;

        //Constructor
        public MyReviewApptActionListener(FrmLabRequest theApp)
        {
            this.parent = theApp;
        }

        @Override
        public void actionPerformed(ActionEvent evt) 
        {
            boolean checkFields = false;
            parent.inputName = txtName.getText();
            
            //If no input in name, assume no event - display event listing w/o new appt, else validate new appt input
            if(parent.inputName.isEmpty()) 
            {
                int rtn = JOptionPane.showConfirmDialog(null, "View scheduled appointments without requesting an appointment?", "View Only", JOptionPane.OK_CANCEL_OPTION);
                if(rtn==JOptionPane.OK_OPTION)
                {
                    //Display Event Listings
                    FrmEventListings otherFrame = new FrmEventListings(parent);
                    otherFrame.setVisible(true);
                    parent.setVisible(false);
                }
            }
            else //i.e. if(!parent.inputName.isEmpty())
            {
                checkFields = validateAll();
                if (checkFields==true) 
                {
                    newEvent = new Event(inputEventTitle, inputEventDate, inputStartTime, inputEndTime);
                
                    //Clear prior events from requestedEvents EventCollection and add new requested event
                    requestedEvents.clearEvents();
                    requestedEvents.addEvent(newEvent);
                
                    //Display Event Listings
                    FrmEventListings otherFrame = new FrmEventListings(parent);
                    otherFrame.setVisible(true);
                    parent.setVisible(false);
                }
                else 
                {
                    JOptionPane.showMessageDialog(null, "Address errors before resubmission", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    //Clear all and resert fields when clear button selected
    class MyClearActionListener implements ActionListener 
    {
        //Constructor
        public MyClearActionListener(FrmLabRequest theApp) {}

        @Override
        public void actionPerformed(ActionEvent e) 
        {
            clearFields();
        }
    }

    //Validate all data and confirm submission when submit chosen
    private class MySubmitActionListener implements ActionListener 
    {
        //Constructor
        public MySubmitActionListener(FrmLabRequest theApp) {}

        @Override
        public void actionPerformed(ActionEvent e) 
        {
            boolean submitCheckFields = validateAll();
            
            if(submitCheckFields==true)
            {        
                //If (non-recurring event) conflicts exist, do not allow submission
                if(recurrence==false) 
                {
                    newEvent = new Event(inputEventTitle, inputEventDate, inputStartTime, inputEndTime);
                    if(newEvent.isAvailable(scheduledEvents)==false)
                    {
                        submitCheckFields=false;
                        JOptionPane.showMessageDialog(null, "Requested event not available", "Conflict", JOptionPane.ERROR_MESSAGE);
                    }
                }
                //If recurring event has no available insances, do not allow submission
                if(recurrence==true && numAvailable==0) 
                {
                    submitCheckFields=false;
                    JOptionPane.showMessageDialog(null, "No recurring event instances available", "Conflict", JOptionPane.ERROR_MESSAGE);
                }
            }
            
            //Check again after availability check
            if(submitCheckFields==true)
            {
                //Display message in pop-up - call messageBuilder to assemble string verifying input
                int rtn = JOptionPane.showConfirmDialog(null, messageBuilder(), "Confirm Lab Request Submission", JOptionPane.OK_CANCEL_OPTION);
                if(rtn==JOptionPane.OK_OPTION)
                {
                    //Add to scheduledEvents EventCollection if available
                    if (recurrence==false && newEvent.isAvailable(scheduledEvents)==true) 
                    {
                        scheduledEvents.addEvent(newEvent);
//                        .csv IO code
//                        try 
//                        {
//                            BufferedWriter oFile = new BufferedWriter(new FileWriter(scheduledFile,true)); //True appends
//                            oFile.write(inputEventTitle + "," + inputEventDate + "," + inputStartTime + "," + inputEndTime);
//                            oFile.newLine();
//                            oFile.close();
//                        } 
//                        catch (FileNotFoundException ex1) 
//                        {
//                            JOptionPane.showMessageDialog(null, ex1, "Error - file not found", JOptionPane.ERROR_MESSAGE);
//                        }
//                        catch (IOException ex2) 
//                        {
//                            JOptionPane.showMessageDialog(null, ex2, "Error - I/O file reader error", JOptionPane.ERROR_MESSAGE);
//                        }
//                        catch (Exception ex3) //Generic exception
//                        {
//                            JOptionPane.showMessageDialog(null, ex3, "Error", JOptionPane.ERROR_MESSAGE);
//                        }
                        try 
                        {
                            writeEventList(scheduledEvents.events);
                        }
                        catch (Exception ex) 
                        {
                            JOptionPane.showMessageDialog(null, ex, "Error accessing file", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                    //If appt recurrs, add only availale instances to EventCollection
                    if (recurrence==true && numAvailable>1) 
                    {
                        //Loop through availableEvents ArrayList, add to scheduledEvents Event Collection
                        for(Event event : availableEvents) 
                        {
                            scheduledEvents.addEvent(event);
                        }
//                        try 
//                        {
//                            BufferedWriter oFile = new BufferedWriter(new FileWriter(scheduledFile,true)); //True appends
//                            for(Event event : availableEvents) 
//                            {
//                                oFile.write(event.getEventTitle() + "," + event.getEventDateStr() + "," + 
//                                        event.getStartTimeStr() + "," + event.getEndTimeStr());
//                                oFile.newLine();
//                            }
//                            oFile.close();
//                        } 
//                        catch (FileNotFoundException ex1) 
//                        {
//                            JOptionPane.showMessageDialog(null, ex1, "Error - file not found", JOptionPane.ERROR_MESSAGE);
//                        }
//                        catch (IOException ex2) 
//                        {
//                            JOptionPane.showMessageDialog(null, ex2, "Error - I/O file reader error", JOptionPane.ERROR_MESSAGE);
//                        }
//                        catch (Exception ex3) //Generic exception
//                        {
//                            JOptionPane.showMessageDialog(null, ex3, "Error", JOptionPane.ERROR_MESSAGE);
//                        }
                        try  
                        {
                            writeEventList(scheduledEvents.events);
                        }
                        catch (Exception ex) 
                        {
                            JOptionPane.showMessageDialog(null, ex, "Error accessing file", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                    
                    //Clear fields for input of next appt
                    clearFields();
                }
            }
            else 
            {
                JOptionPane.showMessageDialog(null, "Please address errors before resubmission", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    //Exit system when close button selected
    public class MyCloseActionListener implements ActionListener 
    {
        //Constructor
        public MyCloseActionListener(FrmLabRequest theApp) 
        {
        }

        @Override
        public void actionPerformed(ActionEvent e) 
        {
            System.exit(0);
        }
    }

    //When FrmApptRecurrence passes string of appt recurrence info back,
    //receive data and disable/un-reqire time/date fields
    public void setApptRecurInfo(String apptRecurInfo) 
    {
        //If apptRecurInfo contains appt recurrence data...
        if(!(apptRecurInfo.isEmpty())) 
        {
            //Set recurrence label text to reflect data, make visible
            this.lblApptRecur.setText(apptRecurInfo);
            this.lblApptRecur.setVisible(true);

            //Trigger recurrence-dependent action
            this.recurrence = true;
        
            //Resert labels
            this.resetLabels();
        
            //Delete input from fields n/a for recurrence
            this.txtDate.setText("");
            this.txtStartTime.setText("");
            this.txtEndTime.setText("");
            this.btnStartPM.setSelected(false);
            this.btnEndPM.setSelected(false);

            //Disable fields n/a for recurrence
            this.txtDate.setEnabled(false);
            this.txtStartTime.setEnabled(false);
            this.txtEndTime.setEnabled(false);
            this.btnStartPM.setEnabled(false);
            this.btnEndPM.setEnabled(false);
            this.btnReview.setEnabled(false);
        }
    }

    //Clear and reset fields when Clear button selected
    private void clearFields() 
    {
        //Clear all field input
        this.txtName.setText("");
        this.txtEmail.setText("");
        this.txtNumParticipants.setText("");
        this.txtEventTitle.setText("");
        this.txtDate.setText("");
        this.txtStartTime.setText("");
        this.txtEndTime.setText("");
        this.txtArea.setText("");

        //Clear all JButton selection
        this.btnStartPM.setSelected(false);
        this.btnEndPM.setSelected(false);
        this.btnPrinterReq.setSelected(false);
        this.btnSpecReqNo.setSelected(true);
        this.btnSpecReqYes.setSelected(false);
        this.txtArea.setVisible(false);
        this.txtAreaPane.setVisible(false);

        //Set all labels back to black
        resetLabels();
        this.btnStartPM.setText("AM");
        this.btnEndPM.setText("AM");

        //Revert recurrence/review-triggered objects to default
        this.lblApptRecur.setVisible(false);
        this.btnReview.setEnabled(true);
        this.recurrence = false;

        //Enable all fields
        this.txtDate.setEnabled(true);
        this.txtStartTime.setEnabled(true);
        this.txtEndTime.setEnabled(true);
        this.btnStartPM.setEnabled(true);
        this.btnEndPM.setEnabled(true);

        //Set focus back to first field
        this.txtName.requestFocus();
    }

    //Reset all labels to black
    private void resetLabels() 
    {
        this.lblName.setForeground(Color.BLACK);
        this.lblEmail.setForeground(Color.BLACK);
        this.lblTitle.setForeground(Color.BLACK);
        this.lblNoParticipants.setForeground(Color.BLACK);
        this.lblDate.setForeground(Color.BLACK);
        this.lblStartTime.setForeground(Color.BLACK);
        this.lblEndTime.setForeground(Color.BLACK);
        this.lblSoftReqSpecInstruct.setForeground(Color.BLACK);
    }

    private void getFormInput() 
    {
        //Assign form values to input variables
        inputName = txtName.getText();
        inputEmail = txtEmail.getText();
        inputEventTitle = txtEventTitle.getText();
        inputArea = txtArea.getText();
        inputNumParticipants = txtNumParticipants.getText();

        //Gather event time/date data if no recurrence
        if (recurrence == false) 
        {
            inputEventDate = txtDate.getText();
            inputStartTime = txtStartTime.getText();
            inputEndTime = txtEndTime.getText();
            if (btnStartPM.isSelected()) 
            {
                inputStartPM = true;
            } 
            else 
            {
                inputStartPM = false;
            }
            if (btnEndPM.isSelected()) 
            {
                inputEndPM = true;
            } 
            else 
            {
                inputEndPM = false;
            }
        }

        if (btnPrinterReq.isSelected()) 
        {
            inputPrinterReq = true;
        } 
        else 
        {
            inputPrinterReq = false;
        }
        if (btnSpecReqYes.isSelected()) 
        {
            inputSpecReq = true;
        } 
        else 
        {
            inputSpecReq = false;
        }
    }

    //Validate that all string/text fields populated
    private void requiredFields(String inputName, String inputEmail, String inputEventTitle,
            String inputEventDate, String inputStartTime, String inputEndTime, String inputSpecReq) {
        if (inputName.isEmpty() || inputEmail.isEmpty() || inputEventTitle.isEmpty()
                || //Only validate time/date info submitted if no recurrence
                (recurrence == false && (inputEventDate.isEmpty() || inputStartTime.isEmpty() || inputEndTime.isEmpty()))
                //Only validate special request details entered if special request radio button selected
                || (btnSpecReqYes.isSelected() && inputArea.isEmpty())) 
        {
            
            //Set labels of missing fields to red
            if (inputName.isEmpty()) 
            {
                txtName.requestFocus();
                lblName.setForeground(Color.RED);
            }
            if (inputEmail.isEmpty()) 
            {
                txtEmail.requestFocus();
                lblEmail.setForeground(Color.RED);
            }
            if (inputEventTitle.isEmpty()) 
            {
                txtEventTitle.requestFocus();
                lblTitle.setForeground(Color.RED);
            }
            if (recurrence == false && inputEventDate.isEmpty()) 
            {
                txtDate.requestFocus();
                lblDate.setForeground(Color.RED);
            }
            if (recurrence == false && inputStartTime.isEmpty()) 
            {
                txtStartTime.requestFocus();
                lblStartTime.setForeground(Color.RED);
            }
            if (recurrence == false && inputEndTime.isEmpty()) 
            {
                txtEndTime.requestFocus();
                lblEndTime.setForeground(Color.RED);
            }
            if (btnSpecReqYes.isSelected() && inputArea.isEmpty()) 
            {
                txtArea.requestFocus();
                lblSoftReqSpecInstruct.setForeground(Color.RED);
            }

            //Throw exception
            throw new IllegalArgumentException("All fields required");
        } 
        else 
        {
            return;
        }
    }

    //Validate format of email input
    private String validateEmail(String email) 
    {
        if (email.matches("\\w+@\\w+.\\w+")) 
        {
            return email;
        } 
        else 
        {
            throw new IllegalArgumentException("Email must be in name@domain.extension format");
        }
    }

    //Validate format of date input
    private String validateDate(String date) 
    {
        //TO DO - resolve 2 year error (e.g. 1/1/13 displays as 01/01/0013)
        if (date.matches("(\\d{1,2}/\\d{1,2}/\\d{2,4})")) 
        {
            return date;
        } 
        else 
        {
            throw new IllegalArgumentException("Date must be in MM/DD/YYYY or M/D/YY format");
        }
    }

    //Validate format of time input
    private String validateTime(String time) 
    {
        if (time.matches("\\d{1,2}:\\d{2}")) 
        {
            return time;
        } 
        else 
        {
            throw new IllegalArgumentException("Time must me in H:MM or HH:MM format");
        }
    }

    //Validate format of number of participants input
    private int validateNumParticipants(String numParticipants) 
    {
        int num = 0;
        try
        {
            num = Integer.parseInt(numParticipants);
        }
        catch (NumberFormatException ex)
        {
            txtNumParticipants.requestFocus();
            lblNoParticipants.setForeground(Color.RED);
            JOptionPane.showMessageDialog(null, "Number of participants required (must be an integer > 0)",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            return 0;
        }
        if (num > 0) 
        {
            return num;
        } 
        else 
        {
            throw new IllegalArgumentException("Number of participants must be an integer > 0");
        }
    }

    //Add AM/PM per JToggleButton to input start and end times
    private void startEndTimes() 
    {
        inputStartPM = btnStartPM.isSelected();
        inputEndPM = btnEndPM.isSelected();
        if (inputStartPM == true) 
        {
            inputStartTime = inputStartTime + " PM";
        } 
        else 
        {
            inputStartTime = inputStartTime + " AM";
        }
        if (inputEndPM == true) 
        {
            inputEndTime = inputEndTime + " PM";
        } 
        else 
        {
            inputEndTime = inputEndTime + " AM";
        }
    }

    //Validate start time < end time
    private void validateStartEndTimes() 
    {
        SimpleDateFormat parser = new SimpleDateFormat("h:mm a");
        Date startTime = null;
        Date endTime = null;
        try 
        {
            startTime = parser.parse(inputStartTime);
        } 
        catch (ParseException ex) 
        {
            Logger.getLogger(FrmLabRequest.class.getName()).log(Level.SEVERE, null, ex);
        }
        try 
        {
            endTime = parser.parse(inputEndTime);
        } 
        catch (ParseException ex) 
        {
            Logger.getLogger(FrmLabRequest.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (endTime.before(startTime)) 
        {
            throw new IllegalArgumentException("End time must be after start time");
        } 
        else 
        {
            return;
        }
    }

    //Build message string based on input variables
    private String messageBuilder() 
    {
        String message = "Name: " + inputName + "\n";
        message = message + "Email: " + inputEmail + "\n";
        message = message + "Event Title: " + inputEventTitle + "\n";
        if (recurrence == false) 
        {
            message = message + "Event Date: " + inputEventDate + "\n";
            message = message + "Start Time: " + inputStartTime + "\n";
            message = message + "End Time: " + inputEndTime + "\n";
        } 
        else 
        {
            message = message + lblApptRecur.getText() + "\n";
        }
        message = message + "Number of Participants: " + inputNumParticipants + "\n";
        message = message + "Printer Requested?: " + inputPrinterReq + "\n";
        if (inputSpecReq == true) 
        {
            message = message + "Special Requests:\n" + inputArea;
        } 
        else 
        {
            message = message + "No special requests noted.";
        }
        return message;
    }

    public boolean validateAll() 
    {
        //Set all labels back to black
        resetLabels();
        
        //Assign form values to input variables
        getFormInput();
      
        //Validate all fields have input
        try 
        {
            requiredFields(inputName, inputEmail, inputEventTitle, inputEventDate,
                    inputStartTime, inputEndTime, inputArea);
        } 
        catch (IllegalArgumentException exc) 
        {
            JOptionPane.showMessageDialog(null, exc, "Input Error", JOptionPane.ERROR_MESSAGE);
            return (false);
        }
        
        //Validate email format
        try 
        {
            validateEmail(inputEmail);
        } 
        catch (IllegalArgumentException exc) 
        {
            txtEmail.requestFocus();
            lblEmail.setForeground(Color.RED);
            JOptionPane.showMessageDialog(null, exc, "Input Error", JOptionPane.ERROR_MESSAGE);
            return (false);
        }
        
        //Validate date/time input only if no recurrence set
        if (recurrence == false) 
        {
            //Validate date in MM/dd/yyyy format
            try 
            {
                validateDate(inputEventDate);
            } 
            catch (IllegalArgumentException exc) 
            {
                txtDate.requestFocus();
                JOptionPane.showMessageDialog(null, exc, "Input Error", JOptionPane.ERROR_MESSAGE);
                return (false);
            }
            
            //Validate start time in HH:MM or H:MM format
            try 
            {
                validateTime(inputStartTime);
            } 
            catch (IllegalArgumentException exc) 
            {
                txtStartTime.requestFocus();
                lblStartTime.setForeground(Color.RED);
                JOptionPane.showMessageDialog(null, exc, "Input Error", JOptionPane.ERROR_MESSAGE);
                return (false);
            }
            
            //Validate end time in HH:MM or H:MM format
            try 
            {
                validateTime(inputEndTime);
            } 
            catch (IllegalArgumentException exc) 
            {
                txtEndTime.requestFocus();
                lblEndTime.setForeground(Color.RED);
                JOptionPane.showMessageDialog(null, exc, "Input Error", JOptionPane.ERROR_MESSAGE);
                return (false);
            }
            
            //Add AM/PM per JToggleButton to input start and end times
            startEndTimes();
            
            //Validate start time < end time
            try 
            {
                validateStartEndTimes();
            }
            catch (IllegalArgumentException exc) 
            {
                txtEndTime.requestFocus();
                lblEndTime.setForeground(Color.RED);
                JOptionPane.showMessageDialog(null, exc, "Input Error", JOptionPane.ERROR_MESSAGE);
                return (false);
            }
        }
        
        //Validate number of participants is > 0
        try
        {
            int num = validateNumParticipants(inputNumParticipants);
            if (num <= 0)
            {
                txtNumParticipants.requestFocus();
                lblNoParticipants.setForeground(Color.RED);
                return (false);
            }
        }
        catch (IllegalArgumentException exc)
        {
            txtNumParticipants.requestFocus();
            lblNoParticipants.setForeground(Color.RED);
            JOptionPane.showMessageDialog(null, exc, "Input Error", JOptionPane.ERROR_MESSAGE);
            return (false);
        }

        return (true);    
    }
}